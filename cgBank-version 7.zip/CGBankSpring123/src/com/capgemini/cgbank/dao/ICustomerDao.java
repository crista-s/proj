package com.capgemini.cgbank.dao;

import com.capgemini.cgbank.bean.UserTable;
import com.capgemini.cgbank.exception.BankException;

public interface ICustomerDao {
	public UserTable getValidUser(int userId,String password)throws BankException;
	public int generateCheque(int accountId)throws BankException;

	public String trackStatus(int requisitionId)throws BankException;
	
}
