package com.capgemini.cgbank.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class CustomerBean {
	@Id
	@Column(name="customerName")
	private String customerName;
	@Column(name="email")
	private String email;
	@Column(name="address")
	private String address;
	@Column(name="panNumber")
	private String panNum;
	@Column(name="phoneNumber")
	private String phoneNumber;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	private AccMasterBean account;
	public CustomerBean() {
		super();
	}
	
	


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}




	public String getPanNum() {
		return panNum;
	}




	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}




	public AccMasterBean getAccount() {
		return account;
	}




	public void setAccount(AccMasterBean account) {
		this.account = account;
	}




	public CustomerBean(String customerName, String email, String address,
			String panNum, String phoneNumber, AccMasterBean account) {
		super();
		this.customerName = customerName;
		this.email = email;
		this.address = address;
		this.panNum = panNum;
		this.phoneNumber = phoneNumber;
		this.account = account;
	}




	@Override
	public String toString() {
		return "CustomerBean [customerName=" + customerName + ", email="
				+ email + ", address=" + address + ", panNum=" + panNum
				+ ", phoneNumber=" + phoneNumber + ", account=" + account + "]";
	}



	
	
	
	
}
