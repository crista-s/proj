package com.capgemini.cgbank.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="userTable")
public class UserTable {
	
	@Id
	@Column(name="userId")
	private int userId;
	@Column(name="userName")
	private String userName;
	@Column(name="password")
	private String password;
	@Column(name="secretquestion")
	private String secretQue;
	@Column(name="secretanswer")
	private String secretAns;
	@Column(name="transactionpassword")
	
	private String transPassword;
	@Column(name="lockstatus")
	private String lockStatus;
	@Column(name="usertype")
	private String userType;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	private AccMasterBean account;
	public String getSecretAns() {
		return secretAns;
	}
	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQue() {
		return secretQue;
	}
	public void setSecretQue(String secretQue) {
		this.secretQue = secretQue;
	}
	public String getTransPassword() {
		return transPassword;
	}
	public void setTransPassword(String transPassword) {
		this.transPassword = transPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public UserTable() {
		super();
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public AccMasterBean getAccount() {
		return account;
	}
	public void setAccount(AccMasterBean account) {
		this.account = account;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public UserTable(AccMasterBean account, int userId, String userName,
			String password, String secretQue, String secretAns,
			String transPassword, String lockStatus, String userType) {
		super();
		this.account = account;
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.secretQue = secretQue;
		this.secretAns = secretAns;
		this.transPassword = transPassword;
		this.lockStatus = lockStatus;
		this.userType = userType;
	}
	@Override
	public String toString() {
		return "UserTable [account=" + account + ", userId=" + userId
				+ ", userName=" + userName + ", password=" + password
				+ ", secretQue=" + secretQue + ", secretAns=" + secretAns
				+ ", transPassword=" + transPassword + ", lockStatus="
				+ lockStatus + ", userType=" + userType + "]";
	}
	
	
	
	
	
}
