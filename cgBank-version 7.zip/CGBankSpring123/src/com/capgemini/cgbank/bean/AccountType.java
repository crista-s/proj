package com.capgemini.cgbank.bean;

public enum AccountType {
	current, savings;

}
