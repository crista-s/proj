package com.capgemini.cgbank.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="FundTransfer")
public class FundTransferBean {
	@Id
	@Column(name="FundTransferId")
	private int fundId;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	private AccMasterBean account;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "payeeId")
	private PayeeBean payee;
	
	
	@Column(name="dateoftransfer")
	private Date dateOfTransfer;
	@Column(name="transactionamount")
	private double transAmount;
	
	public FundTransferBean() {
		super();
	}
	public int getFundId() {
		return fundId;
	}
	public void setFundId(int fundId) {
		this.fundId = fundId;
	}
	
	
	
	public double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}
	public AccMasterBean getAccount() {
		return account;
	}
	public void setAccount(AccMasterBean account) {
		this.account = account;
	}
	public PayeeBean getPayee() {
		return payee;
	}
	public void setPayee(PayeeBean payee) {
		this.payee = payee;
	}
	public Date getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(Date dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public FundTransferBean(int fundId, AccMasterBean account, PayeeBean payee,
			Date dateOfTransfer, double transAmount) {
		super();
		this.fundId = fundId;
		this.account = account;
		this.payee = payee;
		this.dateOfTransfer = dateOfTransfer;
		this.transAmount = transAmount;
	}
	@Override
	public String toString() {
		return "FundTransferBean [fundId=" + fundId + ", account=" + account
				+ ", payee=" + payee + ", dateOfTransfer=" + dateOfTransfer
				+ ", transAmount=" + transAmount + "]";
	}
	

}
